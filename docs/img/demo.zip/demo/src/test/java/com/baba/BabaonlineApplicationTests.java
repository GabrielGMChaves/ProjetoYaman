package com.baba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabaonlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
