package com.baba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BabaonlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(BabaonlineApplication.class, args);
	}

}
